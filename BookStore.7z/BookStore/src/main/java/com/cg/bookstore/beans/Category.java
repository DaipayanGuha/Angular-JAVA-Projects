package com.cg.bookstore.beans;

public enum Category {
	Horror,Romance,Nonfiction,Thriller,Adventure;

}
