package com.cg.bookstore.beans;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

import com.fasterxml.jackson.annotation.JsonFormat;

@Entity
public class Book {
	@Id
	@GeneratedValue(generator = "cust1", strategy = GenerationType.SEQUENCE)
	@SequenceGenerator(name = "cust1", sequenceName = "boo1", initialValue = 1, allocationSize = 1)
	private int bookId;

	@Column(unique = true)
	private String title;

	private String author;

	private String description;
	
	private long iSBN_Number;

	private double price;

	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "dd-MM-yyyy")
	private Date publishDate;

	private int quantity;

	
	private Category category;
	

	public Book() {
		super();
	}
	

	public Book(String title, String author, String description, long iSBN_Number, double price, Date publishDate,
			int quantity, Category category) {
		super();
		this.title = title;
		this.author = author;
		this.description = description;
		this.iSBN_Number = iSBN_Number;
		this.price = price;
		this.publishDate = publishDate;
		this.quantity = quantity;
		this.category = category;
	}
	
	


	public Book(int bookId, String title, String author, String description, long iSBN_Number, double price,
			Date publishDate, int quantity, Category category) {
		super();
		this.bookId = bookId;
		this.title = title;
		this.author = author;
		this.description = description;
		this.iSBN_Number = iSBN_Number;
		this.price = price;
		this.publishDate = publishDate;
		this.quantity = quantity;
		this.category = category;
	}


	public int getBookId() {
		return bookId;
	}

	public void setBookId(int bookId) {
		this.bookId = bookId;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	
	public long getiSBN_Number() {
		return iSBN_Number;
	}


	public void setiSBN_Number(long iSBN_Number) {
		this.iSBN_Number = iSBN_Number;
	}


	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public Date getPublishDate() {
		return publishDate;
	}

	public void setPublishDate(Date publishDate) {
		this.publishDate = publishDate;
	}

	

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", title=" + title + ", author=" + author + ", description=" + description
				+ ", iSBN_Number=" + iSBN_Number + ", price=" + price + ", publishDate=" + publishDate + ", qunatity="
				+ quantity + ", category=" + category + "]";
	}

}
