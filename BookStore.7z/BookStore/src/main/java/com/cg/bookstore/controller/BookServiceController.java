package com.cg.bookstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bookstore.beans.Book;
import com.cg.bookstore.exceptions.BookDetailsNotFoundException;
import com.cg.bookstore.services.BookService;


@RestController
@CrossOrigin(origins="*", maxAge=3600)
public class BookServiceController {
	@Autowired
	BookService bookService;
	@RequestMapping(value= {"/acceptBookDetails"},method=RequestMethod.POST,consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
	public ResponseEntity<String>acceptBookDetailsRequestParam(@ModelAttribute Book book){
		book=bookService.acceptBookDetails(book);
		return new ResponseEntity<>("Book details successfully added book Id :-"+book.getBookId(),HttpStatus.OK);
	}
	@RequestMapping(value= {"/getBookDetails/{bookId}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<Book>getBookDetails(@PathVariable(value="bookId") int bookId) throws BookDetailsNotFoundException{
		return new ResponseEntity<Book>(bookService.getBookDetailsByBookId(bookId),HttpStatus.OK);
	}
	@RequestMapping(value= {"/getAllBookDetails"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Book>>getBookDetailsRequestParam() throws BookDetailsNotFoundException{
		return new ResponseEntity<List<Book>>(bookService.getAllBookDetails(),HttpStatus.OK);
	}
	@RequestMapping(value= {"/getBookByNameDetails/{title}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<Book>getBookDetailsByNameOrTitle(@PathVariable(value="title") String title) throws BookDetailsNotFoundException{
		return new ResponseEntity<Book>(bookService.getBookDetailsByName(title), HttpStatus.OK);
	}
	@RequestMapping(value= {"/getBookDetailsByAuthor/{author}"},method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<List<Book>>getBookDetailsByAuthorList(@PathVariable(value="author") String author) throws BookDetailsNotFoundException{
		return new ResponseEntity<List<Book>>(bookService.getBookDetailsByAuthorName(author),HttpStatus.OK);
	}
	
	@RequestMapping(value= {"/deleteBookByNameDetails"},method=RequestMethod.DELETE,produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json")
	public ResponseEntity<String>deleteBookDetailsByNameOrTitle(@PathVariable(value="title") String title) throws BookDetailsNotFoundException{
		bookService.removeBookDetails(title);
		return new ResponseEntity<String>("Book details successfully removed",HttpStatus.OK);
	}
	
	
	
}
