package com.cg.bookstore.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.bookstore.pagebeans.BookRegistrationBeans;

import cucumber.api.PendingException;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class BookStoreStepDefinition {

	private WebDriver driver;
	private BookRegistrationBeans pageBeans;
	
	@Before
	public void setUpEnv() {
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver = new ChromeDriver();
		
	}
	
	
	@Given("^The user is on the page of registration of the book$")
	public void the_user_is_on_the_page_of_registration_of_the_book() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit data without entering 'title'$")
	public void user_is_trying_to_submit_data_without_entering_title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Title should not be empty' is displayed$")
	public void title_should_not_be_empty_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit data without entering 'author'$")
	public void user_is_trying_to_submit_data_without_entering_author() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Author name should not be empty' is displayed$")
	public void author_name_should_not_be_empty_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit data without entering 'description'$")
	public void user_is_trying_to_submit_data_without_entering_description() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Description should not be empty' is displayed$")
	public void description_should_not_be_empty_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit data without entering 'iSBN_Number'$")
	public void user_is_trying_to_submit_data_without_entering_iSBN_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'iSBN_Number should not be empty' is displayed$")
	public void isbn_number_should_not_be_empty_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit data without entering 'price'$")
	public void user_is_trying_to_submit_data_without_entering_price() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Price should not be empty' is displayed$")
	public void price_should_not_be_empty_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit data without entering 'publishDate'$")
	public void user_is_trying_to_submit_data_without_entering_publishDate() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Publish Date should not be empty' is displayed$")
	public void publish_Date_should_not_be_empty_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit data without entering 'quantity'$")
	public void user_is_trying_to_submit_data_without_entering_quantity() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Quantity should not be empty' is displayed$")
	public void quantity_should_not_be_empty_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit data without entering 'category'$")
	public void user_is_trying_to_submit_data_without_entering_category() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'Category should not be empty' is displayed$")
	public void category_should_not_be_empty_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit after entering valid set of details$")
	public void user_is_trying_to_submit_after_entering_valid_set_of_details() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'The book has been successfully registered' is displayed$")
	public void the_book_has_been_successfully_registered_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^The user is on the getDetailsByName page$")
	public void the_user_is_on_the_getDetailsByName_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit without entering 'title'$")
	public void user_is_trying_to_submit_without_entering_title() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'The title should not be empty' is displayed$")
	public void the_title_should_not_be_empty_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Book Details are shown$")
	public void book_Details_are_shown() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Given("^The user is on the getDetailsById page$")
	public void the_user_is_on_the_getDetailsById_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@When("^User is trying to submit without entering 'book Id'$")
	public void user_is_trying_to_submit_without_entering_book_Id() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^'The book Id should not be empty' is displayed$")
	public void the_book_Id_should_not_be_empty_is_displayed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}
	
	@After
	public void tearDownSetUpEnv() {
		driver.switchTo().alert().dismiss();
		driver.close();
	}
	
}
