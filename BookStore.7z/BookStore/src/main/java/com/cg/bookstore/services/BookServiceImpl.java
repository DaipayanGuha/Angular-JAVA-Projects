package com.cg.bookstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.bookstore.beans.Book;
import com.cg.bookstore.dao.BookDao;
import com.cg.bookstore.exceptions.BookDetailsNotFoundException;
@Component("bookService")
public class BookServiceImpl implements BookService {
@Autowired
	BookDao bookDao; 
	@Override
	public Book acceptBookDetails(Book book) {  //To save the book details
		return bookDao.save(book);
	}

	@Override
	public Book getBookDetailsByBookId(int bookId) throws BookDetailsNotFoundException { //Retrieve using book ID where book Id is the primary key
		
		return bookDao.findById(bookId).orElseThrow(()->new BookDetailsNotFoundException("Sorry! Book Not Found"));
	}

	@Override
	public List<Book> getAllBookDetails() throws BookDetailsNotFoundException { //Retrieve all books from database
		List<Book> books = bookDao.findAll();
		if(books.isEmpty())
			throw new BookDetailsNotFoundException("No books found");
		else
			return books;
	}

	@Override
	public Book getBookDetailsByName(String title) throws BookDetailsNotFoundException { //Retrieve books with the help of name using custom query
		// TODO Auto-generated method stub
		Book book =  bookDao.getBookByTitle(title);
		if(book == null)
			throw new BookDetailsNotFoundException("No such book found with name : "+title);
		else
			return book; 
	}

	@Override
	public List<Book> getBookDetailsByAuthorName(String authorName) throws BookDetailsNotFoundException { //Retrieve books using author name
		// TODO Auto-generated method stub
		
		List<Book> books =  bookDao.getBookByAuthor(authorName);
		if(books.isEmpty())
			throw new BookDetailsNotFoundException("No such book found with author Name : "+authorName);
		else
			return books;
	}

	@Override
	public boolean removeBookDetails(String title) throws BookDetailsNotFoundException { //Delete books using the provided title
		// TODO Auto-generated method stub

		Book book = bookDao.getBookByTitle(title);
		if(book == null)
			throw new BookDetailsNotFoundException("No such book found with name : "+title);
		else
			bookDao.delete(book);
		return true;
	}

	/*@Override
	public List<Book> getBookDetailsByCategory(String categoryName) throws BookDetailsNotFoundException {
		// TODO Auto-generated method stub
		return null;
	}*/

}
